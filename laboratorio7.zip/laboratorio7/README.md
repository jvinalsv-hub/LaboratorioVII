# Laboratorio 7 - API REST con Spring Boot

Proyecto desarrollado aplicando arquitectura por capas, buenas prácticas de desarrollo, almacenamiento en memoria, validaciones con Bean Validation, manejo global de excepciones y seguridad mediante API Key.

---

## 📋 Requisitos y Configuración

- **Java**: 21
- **Spring Boot**: 4.1.2
- **Manejador de dependencias**: Maven Wrapper (`mvnw`)
- **Header de autenticación**: `X-API-KEY`
- **Valor por defecto de la API Key**: `laboratorio7-secret-key-2026` (configurable en `application.properties`)

---

## 🏗️ Arquitectura por Capas

El proyecto está organizado de manera modular en el paquete `com.test.laboratorio7`:

```
src/main/java/com/test/laboratorio7/
├── config/              # Configuración web e interceptor de seguridad API Key
│   ├── ApiKeyInterceptor.java
│   └── WebMvcConfig.java
├── controller/          # Controladores REST con códigos de estado HTTP
│   ├── EmpleadoController.java
│   ├── ProfesorController.java
│   └── ProveedorController.java
├── dto/                 # Data Transfer Objects con validaciones (@NotBlank, @Email)
│   ├── EmpleadoDTO.java
│   ├── ProfesorDTO.java
│   └── ProveedorDTO.java
├── exception/           # Excepciones personalizadas y manejador global
│   ├── ErrorResponse.java
│   ├── GlobalExceptionHandler.java
│   └── ResourceNotFoundException.java
├── model/               # Clases de dominio / entidades
│   ├── Empleado.java
│   ├── Profesor.java
│   └── Proveedor.java
├── repository/          # Almacenamiento en memoria con colecciones seguras
│   ├── EmpleadoRepository.java
│   ├── ProfesorRepository.java
│   └── ProveedorRepository.java
└── service/             # Lógica de negocio (interfaces e implementaciones)
    ├── EmpleadoService.java
    ├── ProfesorService.java
    ├── ProveedorService.java
    └── impl/
        ├── EmpleadoServiceImpl.java
        ├── ProfesorServiceImpl.java
        └── ProveedorServiceImpl.java
```

---

## 🚀 Ejercicios Desarrollados

### Ejercicio 1: API de Profesores
* **Campos**: `id`, `nombre`, `apellido`, `correo`, `especialidad`, `estado`.
* **Endpoints**:
  * `POST /api/profesores`: Crea un profesor (retorna `201 Created`).
  * `GET /api/profesores`: Lista todos los profesores (retorna `200 OK`).
  * `GET /api/profesores?especialidad={especialidad}`: Filtra profesores por especialidad (retorna `200 OK`).
  * `GET /api/profesores/{id}`: Consulta profesor por ID (retorna `200 OK` o `404 Not Found`).

### Ejercicio 2: API de Proveedores
* **Campos**: `id`, `nombre`, `apellido`, `correo`, `categoria`, `estado`.
* **Endpoints**:
  * `POST /api/proveedores`: Crea un proveedor (retorna `201 Created`).
  * `GET /api/proveedores`: Lista todos los proveedores (retorna `200 OK`).
  * `GET /api/proveedores?categoria={categoria}`: Filtra proveedores por categoría (retorna `200 OK`).
  * `GET /api/proveedores/{id}`: Consulta proveedor por ID (retorna `200 OK` o `404 Not Found`).

### Ejercicio 3: API de Empleados
* **Campos**: `id`, `nombre`, `apellido`, `correo`, `especialidad`, `estado`.
* **Endpoints**:
  * `POST /api/empleados`: Crea un empleado (retorna `201 Created`).
  * `GET /api/empleados`: Lista todos los empleados (retorna `200 OK`).
  * `GET /api/empleados?especialidad={especialidad}`: Filtra empleados por especialidad (retorna `200 OK`).
  * `GET /api/empleados/{id}`: Consulta empleado por ID (retorna `200 OK` o `404 Not Found`).

---

## 🔒 Seguridad (API Key)

Todas las rutas bajo `/api/**` requieren el header:
```http
X-API-KEY: laboratorio7-secret-key-2026
```
Si la petición no incluye el header o el valor es incorrecto, el servidor responde con código `401 Unauthorized`.

---

## 🧪 Pruebas Unitarias

Se implementaron pruebas unitarias con **JUnit 5**, **Mockito** y **MockMvc**:

1. **ProfesorServiceTest**:
   - Crear profesor exitosamente.
   - Obtener profesor existente por ID.
   - Obtener profesor inexistente (lanza `ResourceNotFoundException` -> 404).
2. **ProveedorServiceTest**:
   - Crear proveedor exitosamente.
   - Obtener proveedor existente por ID.
   - Obtener proveedor inexistente (lanza `ResourceNotFoundException` -> 404).
3. **EmpleadoServiceTest**:
   - Crear empleado exitosamente.
   - Obtener empleado existente por ID.
   - Obtener empleado inexistente (lanza `ResourceNotFoundException` -> 404).
4. **ApiKeySecurityAndValidationTest**:
   - Petición sin API Key -> 401 Unauthorized.
   - Petición con API Key inválida -> 401 Unauthorized.
   - Validaciones de campos (@NotBlank, @Email) -> 400 Bad Request.
   - Creación exitosa -> 201 Created.
   - Búsqueda inexistente -> 404 Not Found.

### Ejecución de Pruebas:
```bash
./mvnw test
```
(O en Windows PowerShell: `.\mvnw.cmd test`)

---

## 🖥️ Ejemplos de Peticiones con cURL

### 1. Crear Profesor
```bash
curl -X POST http://localhost:8080/api/profesores \
  -H "Content-Type: application/json" \
  -H "X-API-KEY: laboratorio7-secret-key-2026" \
  -d '{
    "nombre": "Carlos",
    "apellido": "Gómez",
    "correo": "carlos.gomez@universidad.edu",
    "especialidad": "Matemáticas",
    "estado": "ACTIVO"
  }'
```

### 2. Filtrar Profesores por Especialidad
```bash
curl -X GET "http://localhost:8080/api/profesores?especialidad=Matemáticas" \
  -H "X-API-KEY: laboratorio7-secret-key-2026"
```

### 3. Consultar Profesor por ID
```bash
curl -X GET http://localhost:8080/api/profesores/1 \
  -H "X-API-KEY: laboratorio7-secret-key-2026"
```
