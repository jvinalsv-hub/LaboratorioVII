package com.test.laboratorio7.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.test.laboratorio7.dto.EmpleadoDTO;
import com.test.laboratorio7.exception.ResourceNotFoundException;
import com.test.laboratorio7.model.Empleado;
import com.test.laboratorio7.repository.EmpleadoRepository;
import com.test.laboratorio7.service.impl.EmpleadoServiceImpl;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class EmpleadoServiceTest {

    @Mock
    private EmpleadoRepository empleadoRepository;

    @InjectMocks
    private EmpleadoServiceImpl empleadoService;

    private Empleado empleadoEjemplo;
    private EmpleadoDTO empleadoDTO;

    @BeforeEach
    void setUp() {
        empleadoEjemplo = Empleado.builder()
                .id(1L)
                .nombre("Ana")
                .apellido("Martínez")
                .correo("ana.martinez@empresa.com")
                .especialidad("Sistemas")
                .estado("ACTIVO")
                .build();

        empleadoDTO = EmpleadoDTO.builder()
                .nombre("Ana")
                .apellido("Martínez")
                .correo("ana.martinez@empresa.com")
                .especialidad("Sistemas")
                .estado("ACTIVO")
                .build();
    }

    @Test
    @DisplayName("Prueba Unitaria 1: Crear empleado exitosamente")
    void testCrearEmpleado() {
        when(empleadoRepository.save(any(Empleado.class))).thenReturn(empleadoEjemplo);

        Empleado creado = empleadoService.crearEmpleado(empleadoDTO);

        assertNotNull(creado);
        assertEquals(1L, creado.getId());
        assertEquals("Ana", creado.getNombre());
        assertEquals("Martínez", creado.getApellido());
        assertEquals("ana.martinez@empresa.com", creado.getCorreo());
        assertEquals("Sistemas", creado.getEspecialidad());
        assertEquals("ACTIVO", creado.getEstado());
        verify(empleadoRepository).save(any(Empleado.class));
    }

    @Test
    @DisplayName("Prueba Unitaria 2: Obtener empleado existente por ID")
    void testObtenerEmpleadoExistente() {
        when(empleadoRepository.findById(1L)).thenReturn(Optional.of(empleadoEjemplo));

        Empleado encontrado = empleadoService.obtenerEmpleadoPorId(1L);

        assertNotNull(encontrado);
        assertEquals(1L, encontrado.getId());
        assertEquals("Ana", encontrado.getNombre());
        verify(empleadoRepository).findById(1L);
    }

    @Test
    @DisplayName("Prueba Unitaria 3: Obtener empleado inexistente lanza 404 ResourceNotFoundException")
    void testObtenerEmpleadoInexistente() {
        when(empleadoRepository.findById(999L)).thenReturn(Optional.empty());

        ResourceNotFoundException exception = assertThrows(
                ResourceNotFoundException.class,
                () -> empleadoService.obtenerEmpleadoPorId(999L)
        );

        assertEquals("Empleado con id 999 no encontrado", exception.getMessage());
        verify(empleadoRepository).findById(999L);
    }
}
