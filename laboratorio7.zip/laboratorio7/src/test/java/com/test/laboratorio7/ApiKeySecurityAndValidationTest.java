package com.test.laboratorio7;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.test.laboratorio7.config.ApiKeyInterceptor;
import com.test.laboratorio7.controller.ProfesorController;
import com.test.laboratorio7.exception.GlobalExceptionHandler;
import com.test.laboratorio7.repository.ProfesorRepository;
import com.test.laboratorio7.service.ProfesorService;
import com.test.laboratorio7.service.impl.ProfesorServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

class ApiKeySecurityAndValidationTest {

    private static final String API_KEY_HEADER = "X-API-KEY";
    private static final String VALID_API_KEY = "laboratorio7-secret-key-2026";
    private static final String INVALID_API_KEY = "clave-incorrecta-xyz";

    private MockMvc mockMvc;
    private ProfesorRepository profesorRepository;
    private ProfesorService profesorService;
    private ProfesorController profesorController;
    private ApiKeyInterceptor apiKeyInterceptor;

    @BeforeEach
    void setUp() {
        profesorRepository = new ProfesorRepository();
        profesorService = new ProfesorServiceImpl(profesorRepository);
        profesorController = new ProfesorController(profesorService);

        apiKeyInterceptor = new ApiKeyInterceptor();
        ReflectionTestUtils.setField(apiKeyInterceptor, "apiKeyHeader", API_KEY_HEADER);
        ReflectionTestUtils.setField(apiKeyInterceptor, "apiSecretKey", VALID_API_KEY);

        mockMvc = MockMvcBuilders.standaloneSetup(profesorController)
                .addInterceptors(apiKeyInterceptor)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    @Test
    @DisplayName("Seguridad: Petición sin API Key retorna 401 Unauthorized")
    void testSinApiKeyRetorna401() throws Exception {
        mockMvc.perform(get("/api/profesores"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.status").value(401))
                .andExpect(jsonPath("$.error").value("Unauthorized"));
    }

    @Test
    @DisplayName("Seguridad: Petición con API Key inválida retorna 401 Unauthorized")
    void testApiKeyInvalidaRetorna401() throws Exception {
        mockMvc.perform(get("/api/profesores")
                        .header(API_KEY_HEADER, INVALID_API_KEY))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.status").value(401));
    }

    @Test
    @DisplayName("Validación: Crear profesor con datos inválidos (nombre vacío y correo erróneo) retorna 400 Bad Request")
    void testCrearProfesorInvalidoRetorna400() throws Exception {
        String jsonInvalido = """
                {
                    \"nombre\": \"\",
                    \"apellido\": \"\",
                    \"correo\": \"correo-no-valido\",
                    \"especialidad\": \"Física\"
                }
                """;

        mockMvc.perform(post("/api/profesores")
                        .header(API_KEY_HEADER, VALID_API_KEY)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonInvalido))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value(400))
                .andExpect(jsonPath("$.validationErrors.nombre").exists())
                .andExpect(jsonPath("$.validationErrors.apellido").exists())
                .andExpect(jsonPath("$.validationErrors.correo").exists());
    }

    @Test
    @DisplayName("API: Crear profesor y consultar por ID retorna 201 y 200")
    void testCrearYConsultarProfesor() throws Exception {
        String jsonValido = """
                {
                    \"nombre\": \"Roberto\",
                    \"apellido\": \"Pérez\",
                    \"correo\": \"roberto.perez@universidad.edu\",
                    \"especialidad\": \"Química\",
                    \"estado\": \"ACTIVO\"
                }
                """;

        mockMvc.perform(post("/api/profesores")
                        .header(API_KEY_HEADER, VALID_API_KEY)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonValido))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.nombre").value("Roberto"));
    }

    @Test
    @DisplayName("API: Consultar recurso inexistente retorna 404 Not Found")
    void testConsultarInexistenteRetorna404() throws Exception {
        mockMvc.perform(get("/api/profesores/99999")
                        .header(API_KEY_HEADER, VALID_API_KEY))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.error").value("Not Found"));
    }
}
