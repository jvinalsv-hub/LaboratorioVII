package com.test.laboratorio7.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.test.laboratorio7.dto.ProveedorDTO;
import com.test.laboratorio7.exception.ResourceNotFoundException;
import com.test.laboratorio7.model.Proveedor;
import com.test.laboratorio7.repository.ProveedorRepository;
import com.test.laboratorio7.service.impl.ProveedorServiceImpl;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ProveedorServiceTest {

    @Mock
    private ProveedorRepository proveedorRepository;

    @InjectMocks
    private ProveedorServiceImpl proveedorService;

    private Proveedor proveedorEjemplo;
    private ProveedorDTO proveedorDTO;

    @BeforeEach
    void setUp() {
        proveedorEjemplo = Proveedor.builder()
                .id(1L)
                .nombre("Distribuidora")
                .apellido("Nacional")
                .correo("contacto@distribuidora.com")
                .categoria("Papelería")
                .estado("ACTIVO")
                .build();

        proveedorDTO = ProveedorDTO.builder()
                .nombre("Distribuidora")
                .apellido("Nacional")
                .correo("contacto@distribuidora.com")
                .categoria("Papelería")
                .estado("ACTIVO")
                .build();
    }

    @Test
    @DisplayName("Prueba Unitaria 1: Crear proveedor exitosamente")
    void testCrearProveedor() {
        when(proveedorRepository.save(any(Proveedor.class))).thenReturn(proveedorEjemplo);

        Proveedor creado = proveedorService.crearProveedor(proveedorDTO);

        assertNotNull(creado);
        assertEquals(1L, creado.getId());
        assertEquals("Distribuidora", creado.getNombre());
        assertEquals("Nacional", creado.getApellido());
        assertEquals("contacto@distribuidora.com", creado.getCorreo());
        assertEquals("Papelería", creado.getCategoria());
        assertEquals("ACTIVO", creado.getEstado());
        verify(proveedorRepository).save(any(Proveedor.class));
    }

    @Test
    @DisplayName("Prueba Unitaria 2: Obtener proveedor existente por ID")
    void testObtenerProveedorExistente() {
        when(proveedorRepository.findById(1L)).thenReturn(Optional.of(proveedorEjemplo));

        Proveedor encontrado = proveedorService.obtenerProveedorPorId(1L);

        assertNotNull(encontrado);
        assertEquals(1L, encontrado.getId());
        assertEquals("Distribuidora", encontrado.getNombre());
        verify(proveedorRepository).findById(1L);
    }

    @Test
    @DisplayName("Prueba Unitaria 3: Obtener proveedor inexistente lanza 404 ResourceNotFoundException")
    void testObtenerProveedorInexistente() {
        when(proveedorRepository.findById(999L)).thenReturn(Optional.empty());

        ResourceNotFoundException exception = assertThrows(
                ResourceNotFoundException.class,
                () -> proveedorService.obtenerProveedorPorId(999L)
        );

        assertEquals("Proveedor con id 999 no encontrado", exception.getMessage());
        verify(proveedorRepository).findById(999L);
    }
}
