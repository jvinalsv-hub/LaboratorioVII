package com.test.laboratorio7.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.test.laboratorio7.dto.ProfesorDTO;
import com.test.laboratorio7.exception.ResourceNotFoundException;
import com.test.laboratorio7.model.Profesor;
import com.test.laboratorio7.repository.ProfesorRepository;
import com.test.laboratorio7.service.impl.ProfesorServiceImpl;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ProfesorServiceTest {

    @Mock
    private ProfesorRepository profesorRepository;

    @InjectMocks
    private ProfesorServiceImpl profesorService;

    private Profesor profesorEjemplo;
    private ProfesorDTO profesorDTO;

    @BeforeEach
    void setUp() {
        profesorEjemplo = Profesor.builder()
                .id(1L)
                .nombre("Carlos")
                .apellido("Gómez")
                .correo("carlos.gomez@universidad.edu")
                .especialidad("Matemáticas")
                .estado("ACTIVO")
                .build();

        profesorDTO = ProfesorDTO.builder()
                .nombre("Carlos")
                .apellido("Gómez")
                .correo("carlos.gomez@universidad.edu")
                .especialidad("Matemáticas")
                .estado("ACTIVO")
                .build();
    }

    @Test
    @DisplayName("Prueba Unitaria 1: Crear profesor exitosamente")
    void testCrearProfesor() {
        when(profesorRepository.save(any(Profesor.class))).thenReturn(profesorEjemplo);

        Profesor creado = profesorService.crearProfesor(profesorDTO);

        assertNotNull(creado);
        assertEquals(1L, creado.getId());
        assertEquals("Carlos", creado.getNombre());
        assertEquals("Gómez", creado.getApellido());
        assertEquals("carlos.gomez@universidad.edu", creado.getCorreo());
        assertEquals("Matemáticas", creado.getEspecialidad());
        assertEquals("ACTIVO", creado.getEstado());
        verify(profesorRepository).save(any(Profesor.class));
    }

    @Test
    @DisplayName("Prueba Unitaria 2: Obtener profesor existente por ID")
    void testObtenerProfesorExistente() {
        when(profesorRepository.findById(1L)).thenReturn(Optional.of(profesorEjemplo));

        Profesor encontrado = profesorService.obtenerProfesorPorId(1L);

        assertNotNull(encontrado);
        assertEquals(1L, encontrado.getId());
        assertEquals("Carlos", encontrado.getNombre());
        verify(profesorRepository).findById(1L);
    }

    @Test
    @DisplayName("Prueba Unitaria 3: Obtener profesor inexistente lanza 404 ResourceNotFoundException")
    void testObtenerProfesorInexistente() {
        when(profesorRepository.findById(999L)).thenReturn(Optional.empty());

        ResourceNotFoundException exception = assertThrows(
                ResourceNotFoundException.class,
                () -> profesorService.obtenerProfesorPorId(999L)
        );

        assertEquals("Profesor con id 999 no encontrado", exception.getMessage());
        verify(profesorRepository).findById(999L);
    }
}
