package com.test.laboratorio7.service.impl;

import com.test.laboratorio7.dto.ProveedorDTO;
import com.test.laboratorio7.exception.ResourceNotFoundException;
import com.test.laboratorio7.model.Proveedor;
import com.test.laboratorio7.repository.ProveedorRepository;
import com.test.laboratorio7.service.ProveedorService;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class ProveedorServiceImpl implements ProveedorService {

    private final ProveedorRepository proveedorRepository;

    public ProveedorServiceImpl(ProveedorRepository proveedorRepository) {
        this.proveedorRepository = proveedorRepository;
    }

    @Override
    public Proveedor crearProveedor(ProveedorDTO dto) {
        String estadoFinal = (dto.getEstado() == null || dto.getEstado().trim().isEmpty())
                ? "ACTIVO"
                : dto.getEstado().trim();

        Proveedor proveedor = Proveedor.builder()
                .nombre(dto.getNombre().trim())
                .apellido(dto.getApellido().trim())
                .correo(dto.getCorreo().trim())
                .categoria(dto.getCategoria().trim())
                .estado(estadoFinal)
                .build();

        return proveedorRepository.save(proveedor);
    }

    @Override
    public List<Proveedor> listarProveedores(String categoria) {
        if (categoria != null && !categoria.trim().isEmpty()) {
            return proveedorRepository.findByCategoria(categoria);
        }
        return proveedorRepository.findAll();
    }

    @Override
    public Proveedor obtenerProveedorPorId(Long id) {
        return proveedorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Proveedor con id " + id + " no encontrado"));
    }
}
