package com.test.laboratorio7.service;

import com.test.laboratorio7.dto.ProfesorDTO;
import com.test.laboratorio7.model.Profesor;
import java.util.List;

public interface ProfesorService {
    Profesor crearProfesor(ProfesorDTO dto);
    List<Profesor> listarProfesores(String especialidad);
    Profesor obtenerProfesorPorId(Long id);
}
