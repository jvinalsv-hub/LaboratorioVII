package com.test.laboratorio7.service.impl;

import com.test.laboratorio7.dto.EmpleadoDTO;
import com.test.laboratorio7.exception.ResourceNotFoundException;
import com.test.laboratorio7.model.Empleado;
import com.test.laboratorio7.repository.EmpleadoRepository;
import com.test.laboratorio7.service.EmpleadoService;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class EmpleadoServiceImpl implements EmpleadoService {

    private final EmpleadoRepository empleadoRepository;

    public EmpleadoServiceImpl(EmpleadoRepository empleadoRepository) {
        this.empleadoRepository = empleadoRepository;
    }

    @Override
    public Empleado crearEmpleado(EmpleadoDTO dto) {
        String estadoFinal = (dto.getEstado() == null || dto.getEstado().trim().isEmpty())
                ? "ACTIVO"
                : dto.getEstado().trim();

        Empleado empleado = Empleado.builder()
                .nombre(dto.getNombre().trim())
                .apellido(dto.getApellido().trim())
                .correo(dto.getCorreo().trim())
                .especialidad(dto.getEspecialidad().trim())
                .estado(estadoFinal)
                .build();

        return empleadoRepository.save(empleado);
    }

    @Override
    public List<Empleado> listarEmpleados(String especialidad) {
        if (especialidad != null && !especialidad.trim().isEmpty()) {
            return empleadoRepository.findByEspecialidad(especialidad);
        }
        return empleadoRepository.findAll();
    }

    @Override
    public Empleado obtenerEmpleadoPorId(Long id) {
        return empleadoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Empleado con id " + id + " no encontrado"));
    }
}
