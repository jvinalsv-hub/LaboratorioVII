package com.test.laboratorio7.repository;

import com.test.laboratorio7.model.Proveedor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;
import org.springframework.stereotype.Repository;

@Repository
public class ProveedorRepository {

    private final List<Proveedor> proveedores = Collections.synchronizedList(new ArrayList<>());
    private final AtomicLong idGenerator = new AtomicLong(1);

    public Proveedor save(Proveedor proveedor) {
        if (proveedor.getId() == null) {
            proveedor.setId(idGenerator.getAndIncrement());
        } else {
            proveedores.removeIf(p -> p.getId().equals(proveedor.getId()));
        }
        proveedores.add(proveedor);
        return proveedor;
    }

    public List<Proveedor> findAll() {
        synchronized (proveedores) {
            return new ArrayList<>(proveedores);
        }
    }

    public Optional<Proveedor> findById(Long id) {
        synchronized (proveedores) {
            return proveedores.stream()
                    .filter(p -> p.getId().equals(id))
                    .findFirst();
        }
    }

    public List<Proveedor> findByCategoria(String categoria) {
        if (categoria == null || categoria.trim().isEmpty()) {
            return findAll();
        }
        synchronized (proveedores) {
            return proveedores.stream()
                    .filter(p -> p.getCategoria() != null &&
                            p.getCategoria().equalsIgnoreCase(categoria.trim()))
                    .collect(Collectors.toList());
        }
    }

    public void clear() {
        proveedores.clear();
        idGenerator.set(1);
    }
}
