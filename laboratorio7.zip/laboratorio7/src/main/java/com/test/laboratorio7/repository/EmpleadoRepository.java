package com.test.laboratorio7.repository;

import com.test.laboratorio7.model.Empleado;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;
import org.springframework.stereotype.Repository;

@Repository
public class EmpleadoRepository {

    private final List<Empleado> empleados = Collections.synchronizedList(new ArrayList<>());
    private final AtomicLong idGenerator = new AtomicLong(1);

    public Empleado save(Empleado empleado) {
        if (empleado.getId() == null) {
            empleado.setId(idGenerator.getAndIncrement());
        } else {
            empleados.removeIf(e -> e.getId().equals(empleado.getId()));
        }
        empleados.add(empleado);
        return empleado;
    }

    public List<Empleado> findAll() {
        synchronized (empleados) {
            return new ArrayList<>(empleados);
        }
    }

    public Optional<Empleado> findById(Long id) {
        synchronized (empleados) {
            return empleados.stream()
                    .filter(e -> e.getId().equals(id))
                    .findFirst();
        }
    }

    public List<Empleado> findByEspecialidad(String especialidad) {
        if (especialidad == null || especialidad.trim().isEmpty()) {
            return findAll();
        }
        synchronized (empleados) {
            return empleados.stream()
                    .filter(e -> e.getEspecialidad() != null &&
                            e.getEspecialidad().equalsIgnoreCase(especialidad.trim()))
                    .collect(Collectors.toList());
        }
    }

    public void clear() {
        empleados.clear();
        idGenerator.set(1);
    }
}
