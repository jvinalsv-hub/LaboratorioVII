package com.test.laboratorio7.service.impl;

import com.test.laboratorio7.dto.ProfesorDTO;
import com.test.laboratorio7.exception.ResourceNotFoundException;
import com.test.laboratorio7.model.Profesor;
import com.test.laboratorio7.repository.ProfesorRepository;
import com.test.laboratorio7.service.ProfesorService;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class ProfesorServiceImpl implements ProfesorService {

    private final ProfesorRepository profesorRepository;

    public ProfesorServiceImpl(ProfesorRepository profesorRepository) {
        this.profesorRepository = profesorRepository;
    }

    @Override
    public Profesor crearProfesor(ProfesorDTO dto) {
        String estadoFinal = (dto.getEstado() == null || dto.getEstado().trim().isEmpty())
                ? "ACTIVO"
                : dto.getEstado().trim();

        Profesor profesor = Profesor.builder()
                .nombre(dto.getNombre().trim())
                .apellido(dto.getApellido().trim())
                .correo(dto.getCorreo().trim())
                .especialidad(dto.getEspecialidad().trim())
                .estado(estadoFinal)
                .build();

        return profesorRepository.save(profesor);
    }

    @Override
    public List<Profesor> listarProfesores(String especialidad) {
        if (especialidad != null && !especialidad.trim().isEmpty()) {
            return profesorRepository.findByEspecialidad(especialidad);
        }
        return profesorRepository.findAll();
    }

    @Override
    public Profesor obtenerProfesorPorId(Long id) {
        return profesorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Profesor con id " + id + " no encontrado"));
    }
}
