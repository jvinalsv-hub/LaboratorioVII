package com.test.laboratorio7.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Proveedor {
    private Long id;
    private String nombre;
    private String apellido;
    private String correo;
    private String categoria;
    private String estado;
}
