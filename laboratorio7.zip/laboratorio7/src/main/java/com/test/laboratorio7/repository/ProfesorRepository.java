package com.test.laboratorio7.repository;

import com.test.laboratorio7.model.Profesor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;
import org.springframework.stereotype.Repository;

@Repository
public class ProfesorRepository {

    private final List<Profesor> profesores = Collections.synchronizedList(new ArrayList<>());
    private final AtomicLong idGenerator = new AtomicLong(1);

    public Profesor save(Profesor profesor) {
        if (profesor.getId() == null) {
            profesor.setId(idGenerator.getAndIncrement());
        } else {
            profesores.removeIf(p -> p.getId().equals(profesor.getId()));
        }
        profesores.add(profesor);
        return profesor;
    }

    public List<Profesor> findAll() {
        synchronized (profesores) {
            return new ArrayList<>(profesores);
        }
    }

    public Optional<Profesor> findById(Long id) {
        synchronized (profesores) {
            return profesores.stream()
                    .filter(p -> p.getId().equals(id))
                    .findFirst();
        }
    }

    public List<Profesor> findByEspecialidad(String especialidad) {
        if (especialidad == null || especialidad.trim().isEmpty()) {
            return findAll();
        }
        synchronized (profesores) {
            return profesores.stream()
                    .filter(p -> p.getEspecialidad() != null &&
                            p.getEspecialidad().equalsIgnoreCase(especialidad.trim()))
                    .collect(Collectors.toList());
        }
    }

    public void clear() {
        profesores.clear();
        idGenerator.set(1);
    }
}
