package com.test.laboratorio7.service;

import com.test.laboratorio7.dto.ProveedorDTO;
import com.test.laboratorio7.model.Proveedor;
import java.util.List;

public interface ProveedorService {
    Proveedor crearProveedor(ProveedorDTO dto);
    List<Proveedor> listarProveedores(String categoria);
    Proveedor obtenerProveedorPorId(Long id);
}
