package com.test.laboratorio7.controller;

import com.test.laboratorio7.dto.ProfesorDTO;
import com.test.laboratorio7.model.Profesor;
import com.test.laboratorio7.service.ProfesorService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/profesores")
public class ProfesorController {

    private final ProfesorService profesorService;

    public ProfesorController(ProfesorService profesorService) {
        this.profesorService = profesorService;
    }

    @PostMapping
    public ResponseEntity<Profesor> crearProfesor(@Valid @RequestBody ProfesorDTO dto) {
        Profesor nuevoProfesor = profesorService.crearProfesor(dto);
        return new ResponseEntity<>(nuevoProfesor, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Profesor>> listarProfesores(
            @RequestParam(required = false) String especialidad) {
        List<Profesor> profesores = profesorService.listarProfesores(especialidad);
        return ResponseEntity.ok(profesores);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Profesor> obtenerProfesorPorId(@PathVariable Long id) {
        Profesor profesor = profesorService.obtenerProfesorPorId(id);
        return ResponseEntity.ok(profesor);
    }
}
