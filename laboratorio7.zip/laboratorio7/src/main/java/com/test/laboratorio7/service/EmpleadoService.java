package com.test.laboratorio7.service;

import com.test.laboratorio7.dto.EmpleadoDTO;
import com.test.laboratorio7.model.Empleado;
import java.util.List;

public interface EmpleadoService {
    Empleado crearEmpleado(EmpleadoDTO dto);
    List<Empleado> listarEmpleados(String especialidad);
    Empleado obtenerEmpleadoPorId(Long id);
}
