package com.test.laboratorio7.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class ApiKeyInterceptor implements HandlerInterceptor {

    @Value("${api.key.header:X-API-KEY}")
    private String apiKeyHeader;

    @Value("${api.key.secret:laboratorio7-secret-key-2026}")
    private String apiSecretKey;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        // Permitir llamadas OPTIONS preflight para CORS
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }

        // Permitir API Key tanto por Header como por Query Param (?X-API-KEY=...)
        String providedKey = request.getHeader(apiKeyHeader);
        if (providedKey == null || providedKey.trim().isEmpty()) {
            providedKey = request.getParameter(apiKeyHeader);
        }

        if (providedKey == null || !providedKey.trim().equals(apiSecretKey)) {
            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            response.setContentType(MediaType.APPLICATION_JSON_VALUE);
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(
                    "{\"status\":401,\"error\":\"Unauthorized\",\"message\":\"Acceso denegado: API Key no proporcionada o inválida\"}"
            );
            return false;
        }

        return true;
    }
}
